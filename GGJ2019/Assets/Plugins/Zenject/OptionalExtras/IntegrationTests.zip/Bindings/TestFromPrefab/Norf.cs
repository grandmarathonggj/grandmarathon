using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefab
{
    public interface INorf
    {
    }

    public class Norf : MonoBehaviour, INorf
    {
    }
}
